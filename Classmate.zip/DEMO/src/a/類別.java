package a;

public class 類別 {
	// 具有屬性、方法
	// 在類別內宣告的變數 → 屬性（單純的值或物件）
	// byte short int long
	// float double 
	// char boolean
	
	int salary;
	int age;
	// 參考資料型別
	
	String s;
	// 屬性
	
	public void getBanana() {
		return;
	}
	// static: 程式開始的時候就存在記憶體裡面
	
	
}
