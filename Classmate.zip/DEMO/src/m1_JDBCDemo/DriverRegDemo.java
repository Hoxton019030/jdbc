package m1_JDBCDemo;

public class DriverRegDemo {

	public static void main(String[] args) {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("註冊完成");
		} catch (ClassNotFoundException e) {
			System.out.println("註冊失敗");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
