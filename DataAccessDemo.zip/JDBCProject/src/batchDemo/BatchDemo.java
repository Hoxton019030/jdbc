package batchDemo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class BatchDemo {

	public static void main(String[] args) {

		String url = "jdbc:sqlserver://localhost:1433;databasename=Northwind";
		String user = "banana";
		String pwd = "a1234";
		String sql = "INSERT INTO [dbo].[Shippers]"
				+ "           ([CompanyName],[Phone])"
				+ "     VALUES (,)";

		try (Connection conn = DriverManager.getConnection(url, user, pwd)) {
			Statement stmt = conn.createStatement();
//			stmt.addBatch("INSERT INTO [dbo].[Shippers]"
//				+ "           ([CompanyName],[Phone])"
//				+ "     VALUES ('ABC','0987654321')");
//			stmt.addBatch("INSERT INTO [dbo].[Shippers]"
//					+ "           ([CompanyName],[Phone])"
//					+ "     VALUES ('DEF','0987123456')");
//			stmt.addBatch("INSERT INTO [dbo].[Shippers]"
//					+ "           ([CompanyName],[Phone])"
//					+ "     VALUES ('GHI','0912345678')");
//			int[] executeBatch = stmt.executeBatch();
//			for (int i = 0; i < executeBatch.length; i++) {
//				System.out.println(executeBatch[i]);
//				
//			}
			

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getErrorCode());
		}

	}

}
