package batchDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;



public class BatchDemo2 {

	public static void main(String[] args) {

		String url = "jdbc:sqlserver://localhost:1433;databasename=Northwind";
		String user = "banana";
		String pwd = "a1234";
		String sql = "INSERT INTO [dbo].[Shippers]"
				+ "           ([CompanyName],[Phone])"
				+ "     VALUES (?,?)";
//		stmt.addBatch("INSERT INTO [dbo].[Shippers]"
//				+ "           ([CompanyName],[Phone])"
//				+ "     VALUES ('ABC','0987654321')");
//			stmt.addBatch("INSERT INTO [dbo].[Shippers]"
//					+ "           ([CompanyName],[Phone])"
//					+ "     VALUES ('DEF','0987123456')");
//			stmt.addBatch("INSERT INTO [dbo].[Shippers]"
//					+ "           ([CompanyName],[Phone])"
//					+ "     VALUES ('GHI','0912345678')");
//			int[] executeBatch = stmt.executeBatch();
//			for (int i = 0; i < executeBatch.length; i++) {
//				System.out.println(executeBatch[i]);
//				
//			}
		try (Connection conn = DriverManager.getConnection(url, user, pwd)) {
			 PreparedStatement pstmt = conn.prepareStatement(sql);	
			 pstmt.setString(1, "Banana");
			 pstmt.setString(2, "0987987987");
			 pstmt.addBatch();
			 pstmt.setString(1, "Apple");
			 pstmt.setString(2, "0987789789");
			 pstmt.addBatch();
			 pstmt.setString(1, "Orange");
			 pstmt.setString(2, "0987897897");
			 pstmt.addBatch();
			 int[] executeBatch = pstmt.executeBatch();
			 for (int i = 0; i < executeBatch.length; i++) {
				int j = executeBatch[i];
				System.out.println(j);
			}
			

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getErrorCode());
		}

	}

}
