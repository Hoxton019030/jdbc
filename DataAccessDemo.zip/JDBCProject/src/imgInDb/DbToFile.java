package imgInDb;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbToFile {

	public static void main(String[] args) {
		
		
		String url="jdbc:sqlserver://localhost:1433;databasename=Northwind";
		String user="banana";
		String pwd="a1234";
		String sql="SELECT [Imgname],[imgFile]"
				+ "  FROM ImageTable where Imgname =?";
		try(Connection conn = DriverManager.getConnection(url, user, pwd)){
			PreparedStatement pstmt = conn.prepareStatement(sql);		
			pstmt.setString(1, "C:\\img\\目標十元阿罵.png");
			ResultSet rs = pstmt.executeQuery();
			FileOutputStream fos=new FileOutputStream("C:\\img\\目標十元阿罵3.png");
			while(rs.next()) {
				InputStream binaryStream = rs.getBinaryStream("imgFile");
				int data=0;
				while ((data=binaryStream.read())!=-1) {
					fos.write(data);
				}				
			}
			fos.close();
			System.out.println("OK");
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
	}

}
