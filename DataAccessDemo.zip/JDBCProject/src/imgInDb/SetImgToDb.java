package imgInDb;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SetImgToDb {

	public static void main(String[] args) {
		
		
		String url="jdbc:sqlserver://localhost:1433;databasename=Northwind";
		String user="banana";
		String pwd="a1234";
		String sql="INSERT INTO [dbo].[ImageTable]"
				+ "           ([Imgname],[imgFile])"
				+ "     VALUES(?,?)";
		
		String imgName = "C:\\img\\目標十元阿罵.png";
		try(Connection conn = DriverManager.getConnection(url, user, pwd);
				FileInputStream fis=new FileInputStream(imgName)){
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, imgName);
			pstmt.setBinaryStream(2, fis);
			int count = pstmt.executeUpdate();
			System.out.println(count);		
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}

}
