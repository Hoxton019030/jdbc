package procedureDemo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CallProcDemo {

	public static void main(String[] args) {
		String url="jdbc:sqlserver://localhost:1433;databasename=Northwind";
		String user="banana";
		String pwd="a1234";
		
		try(Connection conn = DriverManager.getConnection(url, user, pwd)){
			CallableStatement pcall = conn.prepareCall("{call CustOrdersOrders(?)}");//?=>nchar(5)
			pcall.setString(1,"ALFKI");
			boolean haveRs = pcall.execute();
			ResultSet rs = pcall.getResultSet();
			while(rs.next()) {
			System.out.print("OrderID"+rs.getString(1)+"\t");
				System.out.print("OrderDate"+rs.getString(2)+"\t");
				System.out.print("RequiredDate"+rs.getString(3)+"\t");
				System.out.println("ShippedDaters"+rs.getString(4)+"\t");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
